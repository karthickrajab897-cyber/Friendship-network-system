/* ============================================================
   Smart Friendship Network — Main Application Logic
   ============================================================ */

const API = '';
let currentUserId = null;
let allUsers = [];

// ──────────────── Offline Mock Fetch ────────────────
const originalFetch = window.fetch;
window.fetch = async function (url, options) {
    if (!url || typeof url !== 'string' || !url.includes('/api/')) return originalFetch(url, options);

    const jsonResponse = (data, status = 200) => Promise.resolve({
        ok: status >= 200 && status < 300,
        status: status,
        json: () => Promise.resolve(data)
    });

    try {
        const users = JSON.parse(localStorage.getItem('sfn_users') || '[]');
        if (url.includes('/api/users') && (!options || options.method === 'GET')) {
            return jsonResponse(users);
        }
        if (url.includes('/api/dashboard/stats')) {
            return jsonResponse({
                totalUsers: users.length, totalConnections: 0, pendingRequests: 0,
                popularInterests: [{ name: 'Coding', count: 1 }],
                growthData: [1], popularSkills: [{ name: 'JS', count: 1 }]
            });
        }
        if (url.includes('/api/dashboard/user/')) {
            return jsonResponse({ totalFriends: 0, pendingRequests: 0, likemindedMatches: [] });
        }
        if (url.includes('/api/friends/requests/')) return jsonResponse([]);
        if (url.includes('/api/friends/')) return jsonResponse([]);
        if (url.includes('/api/user/')) return jsonResponse(users[0] || {});
        if (url.includes('/suggestions')) return jsonResponse([]);

        return jsonResponse({});
    } catch (e) {
        return jsonResponse({ error: 'Offline mode error' }, 500);
    }
};

// ──────────────── Initialization ────────────────
document.addEventListener('DOMContentLoaded', () => {
    loadUsers();
    setupNavigation();
    setupSidebarToggle();
    setupRegisterForm();
    navigateTo('dashboard');
});

// ──────────────── Navigation ────────────────
function setupNavigation() {
    document.querySelectorAll('.nav-item[data-page]').forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            const page = item.dataset.page;
            navigateTo(page);
            // Close mobile sidebar
            document.getElementById('sidebar').classList.remove('open');
        });
    });
}

function navigateTo(page) {
    // Update nav active state
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
    const navItem = document.querySelector(`[data-page="${page}"]`);
    if (navItem) navItem.classList.add('active');

    // Show page
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    const pageEl = document.getElementById(`page-${page}`);
    if (pageEl) pageEl.classList.add('active');

    // Load page data
    switch (page) {
        case 'dashboard': loadDashboard(); break;
        case 'network': loadNetworkGraph(); break;
        case 'users': renderUsersPage(); break;
        case 'suggestions': loadSuggestions(); break;
        case 'friends': loadFriends(); break;
        case 'profile': loadProfile(); break;
    }
}

// ──────────────── Sidebar Toggle ────────────────
function setupSidebarToggle() {
    const toggle = document.getElementById('sidebarToggle');
    const sidebar = document.getElementById('sidebar');
    if (toggle) {
        toggle.addEventListener('click', () => sidebar.classList.toggle('open'));
    }
    // Close on click outside
    document.addEventListener('click', (e) => {
        if (window.innerWidth < 992 && !sidebar.contains(e.target) && !toggle.contains(e.target)) {
            sidebar.classList.remove('open');
        }
    });
}

// ──────────────── Load Users ────────────────
async function loadUsers() {
    try {
        const res = await fetch(`${API}/api/users`);
        allUsers = await res.json();
        populateUserSelectors();
        // Default to first user
        if (allUsers.length > 0 && !currentUserId) {
            currentUserId = allUsers[0].id;
            document.getElementById('currentUserSelect').value = currentUserId;
        }
    } catch (err) {
        console.error('Failed to load users:', err);
    }
}

function populateUserSelectors() {
    const selectors = ['currentUserSelect', 'pathFrom', 'pathTo'];
    selectors.forEach(id => {
        const sel = document.getElementById(id);
        if (!sel) return;
        const currentVal = sel.value;
        if (id === 'currentUserSelect') {
            sel.innerHTML = '<option value="">Select User...</option>';
        } else {
            sel.innerHTML = '<option value="">Choose...</option>';
        }
        allUsers.forEach(u => {
            const opt = document.createElement('option');
            opt.value = u.id;
            opt.textContent = u.name;
            sel.appendChild(opt);
        });
        if (currentVal) sel.value = currentVal;
    });

    // User selector change
    document.getElementById('currentUserSelect').addEventListener('change', (e) => {
        currentUserId = e.target.value ? parseInt(e.target.value) : null;
        // Refresh current page
        const activePage = document.querySelector('.page.active');
        if (activePage) {
            const pageId = activePage.id.replace('page-', '');
            navigateTo(pageId);
        }
    });
}

// ──────────────── Dashboard ────────────────
async function loadDashboard() {
    try {
        if (currentUserId) {
            // Personal Dashboard
            const res = await fetch(`${API}/api/dashboard/user/${currentUserId}`);
            const data = await res.json();
            renderPersonalDashboard(data);
        } else {
            // Global Dashboard
            const res = await fetch(`${API}/api/dashboard/stats`);
            const stats = await res.json();

            document.getElementById('globalStats').style.display = 'flex';
            document.getElementById('personalStats').style.display = 'none';
            document.getElementById('likemindedSection').style.display = 'none';

            // Animate stat numbers
            animateNumber('statTotalUsers', stats.totalUsers);
            animateNumber('statTotalConnections', stats.totalConnections);
            animateNumber('statPendingRequests', stats.pendingRequests);

            // Render charts
            renderInterestsChart(stats.popularInterests);
            renderGrowthChart(stats.growthData);
            renderSkillsBars(stats.popularSkills);
        }
    } catch (err) {
        console.error('Failed to load dashboard:', err);
    }
}

function renderPersonalDashboard(data) {
    document.getElementById('globalStats').style.display = 'none';
    document.getElementById('personalStats').style.display = 'flex';
    document.getElementById('likemindedSection').style.display = 'block';

    // Animate personal stats
    animateNumber('personalTotalFriends', data.totalFriends);
    animateNumber('personalPendingRequests', data.pendingRequests);

    // Update charts/skills based on personal profile or global context
    // For now, we keep the global charts but maybe highlight personal skill matches
    fetch(`${API}/api/dashboard/stats`)
        .then(res => res.json())
        .then(stats => {
            renderInterestsChart(stats.popularInterests);
            renderGrowthChart(stats.growthData);
            renderSkillsBars(stats.popularSkills);
        });

    // Render Likeminded Connectivity
    const likemindedContainer = document.getElementById('likemindedMatches');
    if (data.likemindedMatches && data.likemindedMatches.length > 0) {
        likemindedContainer.innerHTML = data.likemindedMatches.map(m => {
            const user = m.user;
            const initials = getInitials(user.name);
            return `
                <div class="col-lg-4 col-md-6 animate-in">
                    <div class="companion-card" onclick="viewUserProfile(${user.id})">
                        <div class="companion-header">
                            <div class="user-avatar" style="background: ${user.avatarColor || '#00d4ff'}; width: 40px; height: 40px; font-size: 0.9rem;">
                                ${initials}
                            </div>
                            <div class="flex-fill">
                                <h6 class="mb-0" style="font-size: 0.95rem;">${user.name}</h6>
                                <div class="companion-score-badge mt-1">
                                    <i class="bi bi-stars"></i> ${m.score}% Match
                                </div>
                            </div>
                        </div>
                        <div class="companion-reasons">
                            ${m.reasons.slice(0, 2).join(' • ')}
                        </div>
                        <div class="companion-footer">
                            <button class="btn btn-glow btn-sm flex-fill" onclick="event.stopPropagation(); sendFriendRequest(${user.id})">
                                <i class="bi bi-person-plus"></i> Connect
                            </button>
                        </div>
                    </div>
                </div>
            `;
        }).join('');
    } else {
        likemindedContainer.innerHTML = '<div class="col-12"><p class="text-muted small">Expand your network to find more likeminded friends!</p></div>';
    }
}

function animateNumber(elementId, target) {
    const el = document.getElementById(elementId);
    if (!el) return;
    let current = 0;
    const duration = 1200;
    const step = target / (duration / 16);
    const animate = () => {
        current = Math.min(current + step, target);
        el.textContent = Math.round(current);
        if (current < target) requestAnimationFrame(animate);
    };
    animate();
}

function renderSkillsBars(skills) {
    const container = document.getElementById('popularSkills');
    if (!container || !skills) return;
    const maxCount = skills.length > 0 ? skills[0].count : 1;
    container.innerHTML = skills.map(s => `
        <div class="skill-bar-item animate-in">
            <span class="skill-bar-label">${s.name}</span>
            <div class="skill-bar-track">
                <div class="skill-bar-fill" style="width: 0%;" data-width="${(s.count / maxCount * 100)}%"></div>
            </div>
            <span class="skill-bar-count">${s.count}</span>
        </div>
    `).join('');

    // Trigger animation
    requestAnimationFrame(() => {
        container.querySelectorAll('.skill-bar-fill').forEach(bar => {
            bar.style.width = bar.dataset.width;
        });
    });
}

// ──────────────── Users Page ────────────────
function renderUsersPage() {
    const grid = document.getElementById('usersGrid');
    if (!grid) return;
    grid.innerHTML = allUsers.map((u, i) => createUserCard(u, i)).join('');
}

function createUserCard(user, index) {
    const initials = getInitials(user.name);
    const interests = user.interests ? user.interests.split(',').slice(0, 3) : [];
    const skills = user.skills ? user.skills.split(',').slice(0, 3) : [];

    return `
        <div class="col-lg-4 col-md-6 animate-in">
            <div class="user-card" onclick="viewUserProfile(${user.id})">
                <div class="user-card-header">
                    <div class="user-avatar" style="background: ${user.avatarColor || '#00d4ff'}">
                        ${initials}
                    </div>
                    <div>
                        <h6>${user.name}</h6>
                        <small><i class="bi bi-geo-alt"></i>${user.location || 'Unknown'}</small>
                    </div>
                </div>
                <p class="user-card-bio">${user.bio || 'No bio yet.'}</p>
                <div class="tags-container">
                    ${interests.map(i => `<span class="tag tag-interest">${i.trim()}</span>`).join('')}
                    ${skills.map(s => `<span class="tag tag-skill">${s.trim()}</span>`).join('')}
                </div>
                <div class="user-card-footer">
                    <button class="btn btn-outline-primary btn-sm" onclick="event.stopPropagation(); viewUserProfile(${user.id})">
                        <i class="bi bi-person"></i> View
                    </button>
                    ${currentUserId && currentUserId !== user.id ? `
                        <button class="btn btn-glow btn-sm" onclick="event.stopPropagation(); sendFriendRequest(${user.id})">
                            <i class="bi bi-person-plus"></i> Add
                        </button>
                    ` : ''}
                </div>
            </div>
        </div>
    `;
}

// ──────────────── User Profile ────────────────
async function viewUserProfile(userId) {
    currentProfileId = userId;
    navigateTo('profile');
}

async function loadProfile() {
    const userId = currentProfileId || currentUserId;
    if (!userId) {
        document.getElementById('profileContent').innerHTML = '<div class="alert alert-info"><i class="bi bi-info-circle"></i> Select a user to view their profile.</div>';
        return;
    }

    try {
        const [userRes, friendsRes] = await Promise.all([
            fetch(`${API}/api/users/${userId}`),
            fetch(`${API}/api/friends/${userId}`)
        ]);

        const user = await userRes.json();
        const friends = await friendsRes.json();

        let mutualHtml = '';
        if (currentUserId && currentUserId !== userId) {
            const mutualRes = await fetch(`${API}/api/friends/mutual/${currentUserId}/${userId}`);
            const mutual = await mutualRes.json();
            if (mutual.length > 0) {
                mutualHtml = `
                    <div class="profile-section">
                        <h5 class="section-title"><i class="bi bi-people-fill text-green"></i> Mutual Friends (${mutual.length})</h5>
                        <div class="d-flex flex-wrap gap-2">
                            ${mutual.map(m => `
                                <div class="mutual-badge">
                                    <i class="bi bi-person-fill"></i> ${m.name}
                                </div>
                            `).join('')}
                        </div>
                    </div>
                `;
            }
        }

        const initials = getInitials(user.name);
        const interests = user.interests ? user.interests.split(',') : [];
        const skills = user.skills ? user.skills.split(',') : [];

        document.getElementById('profileContent').innerHTML = `
            <div class="profile-hero" style="--accent: ${user.avatarColor || '#00d4ff'}">
                <div style="position: absolute; top:0; left:0; right:0; height:120px; background: linear-gradient(135deg, ${user.avatarColor || '#00d4ff'}33, transparent); border-radius: var(--radius) var(--radius) 0 0;"></div>
                <div class="profile-avatar-lg" style="background: ${user.avatarColor || '#00d4ff'}">${initials}</div>
                <h2 class="profile-name">${user.name}</h2>
                <p class="profile-location"><i class="bi bi-geo-alt"></i> ${user.location || 'Unknown'}</p>
                <p class="profile-bio">${user.bio || ''}</p>
                ${currentUserId && currentUserId !== user.id ? `
                    <button class="btn btn-glow mt-3" onclick="sendFriendRequest(${user.id})">
                        <i class="bi bi-person-plus"></i> Add Friend
                    </button>
                ` : ''}
            </div>

            <div class="row g-4">
                <div class="col-md-6">
                    <div class="profile-section">
                        <h5 class="section-title"><i class="bi bi-heart text-cyan"></i> Interests</h5>
                        <div class="tags-container">
                            ${interests.map(i => `<span class="tag tag-interest">${i.trim()}</span>`).join('')}
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="profile-section">
                        <h5 class="section-title"><i class="bi bi-lightning text-purple"></i> Skills</h5>
                        <div class="tags-container">
                            ${skills.map(s => `<span class="tag tag-skill">${s.trim()}</span>`).join('')}
                        </div>
                    </div>
                </div>
            </div>

            ${mutualHtml}

            <div class="profile-section">
                <h5 class="section-title"><i class="bi bi-people text-amber"></i> Friends (${friends.length})</h5>
                <div class="row g-3">
                    ${friends.map(f => `
                        <div class="col-md-4 col-6">
                            <div class="d-flex align-items-center gap-2 p-2 rounded" style="background: rgba(255,255,255,0.03); cursor: pointer;" onclick="viewUserProfile(${f.id})">
                                <div class="user-avatar" style="background: ${f.avatarColor || '#00d4ff'}; width: 36px; height: 36px; font-size: 0.8rem; border-radius: 10px;">
                                    ${getInitials(f.name)}
                                </div>
                                <span style="font-size: 0.85rem; font-weight: 500;">${f.name}</span>
                            </div>
                        </div>
                    `).join('')}
                    ${friends.length === 0 ? '<p class="text-muted">No friends yet.</p>' : ''}
                </div>
            </div>
        `;
    } catch (err) {
        console.error('Failed to load profile:', err);
    }
}

let currentProfileId = null;

// ──────────────── Suggestions ────────────────
async function loadSuggestions() {
    if (!currentUserId) {
        document.getElementById('noUserWarning').style.display = 'block';
        document.getElementById('suggestionsGrid').innerHTML = '';
        return;
    }
    document.getElementById('noUserWarning').style.display = 'none';

    try {
        const res = await fetch(`${API}/api/users/${currentUserId}/suggestions`);
        const suggestions = await res.json();
        const grid = document.getElementById('suggestionsGrid');

        grid.innerHTML = suggestions.map((s, i) => {
            const user = s.user;
            const initials = getInitials(user.name);
            const interests = user.interests ? user.interests.split(',').slice(0, 3) : [];
            const scoreOffset = 157 - (157 * s.score / 100);

            return `
                <div class="col-lg-4 col-md-6 animate-in">
                    <div class="suggestion-card">
                        <div class="user-card-header">
                            <div class="user-avatar" style="background: ${user.avatarColor || '#00d4ff'}">
                                ${initials}
                            </div>
                            <div>
                                <h6>${user.name}</h6>
                                <small><i class="bi bi-geo-alt"></i>${user.location || 'Unknown'}</small>
                            </div>
                        </div>

                        <div class="compatibility-score">
                            <div class="score-circle">
                                <svg viewBox="0 0 56 56">
                                    <circle class="bg" cx="28" cy="28" r="25"/>
                                    <circle class="fg" cx="28" cy="28" r="25" style="stroke-dashoffset: ${scoreOffset}; stroke: ${getScoreColor(s.score)}"/>
                                </svg>
                                <span style="color: ${getScoreColor(s.score)}">${s.score}%</span>
                            </div>
                            <span class="score-label">Compatibility Score</span>
                        </div>

                        <div class="mb-3">
                            ${s.reasons.map(r => `<span class="reason-tag"><i class="bi bi-star-fill"></i>${r}</span>`).join('')}
                        </div>

                        <div class="tags-container mb-3">
                            ${interests.map(i => `<span class="tag tag-interest">${i.trim()}</span>`).join('')}
                        </div>

                        <div class="d-flex gap-2">
                            <button class="btn btn-glow btn-sm flex-fill" onclick="sendFriendRequest(${user.id})">
                                <i class="bi bi-person-plus"></i> Connect
                            </button>
                            <button class="btn btn-outline-primary btn-sm" onclick="viewUserProfile(${user.id})">
                                <i class="bi bi-eye"></i>
                            </button>
                        </div>
                    </div>
                </div>
            `;
        }).join('');
    } catch (err) {
        console.error('Failed to load suggestions:', err);
    }
}

function getScoreColor(score) {
    if (score >= 70) return '#10b981'; // green
    if (score >= 40) return '#00d4ff'; // cyan/accent-primary
    return '#f59e0b'; // amber
}

// ──────────────── Friends List ────────────────
async function loadFriends() {
    if (!currentUserId) {
        document.getElementById('friendsList').innerHTML = '<p class="text-muted">Please select a user first.</p>';
        return;
    }

    try {
        // Load friends and pending requests in parallel
        const [friendsRes, requestsRes] = await Promise.all([
            fetch(`${API}/api/friends/${currentUserId}`),
            fetch(`${API}/api/friends/requests/${currentUserId}`)
        ]);

        const friends = await friendsRes.json();
        const requests = await requestsRes.json();

        // Pending requests
        const pendingSection = document.getElementById('pendingSection');
        const pendingContainer = document.getElementById('pendingRequests');

        if (requests.length > 0) {
            pendingSection.style.display = 'block';
            // Need to fetch sender info for each request
            const senderPromises = requests.map(r => fetch(`${API}/api/users/${r.senderId}`).then(res => res.json()));
            const senders = await Promise.all(senderPromises);

            pendingContainer.innerHTML = requests.map((r, i) => {
                const sender = senders[i];
                return `
                    <div class="col-12">
                        <div class="request-card animate-in">
                            <div class="request-info">
                                <div class="user-avatar" style="background: ${sender.avatarColor || '#f59e0b'}; width: 40px; height: 40px; font-size: 0.9rem; border-radius: 10px;">
                                    ${getInitials(sender.name)}
                                </div>
                                <div>
                                    <strong>${sender.name}</strong>
                                    <small class="d-block text-muted">${sender.location || ''}</small>
                                </div>
                            </div>
                            <div class="request-actions">
                                <button class="btn-accept" onclick="acceptFriendRequest(${r.id})">
                                    <i class="bi bi-check-lg"></i> Accept
                                </button>
                                <button class="btn-reject" onclick="rejectFriendRequest(${r.id})">
                                    <i class="bi bi-x-lg"></i> Reject
                                </button>
                            </div>
                        </div>
                    </div>
                `;
            }).join('');
        } else {
            pendingSection.style.display = 'none';
        }

        // Friends list
        const friendsList = document.getElementById('friendsList');
        if (friends.length === 0) {
            friendsList.innerHTML = '<p class="text-muted">No friends yet. Start connecting!</p>';
            return;
        }

        // Get mutual friend counts for each friend
        const mutualPromises = friends.map(f =>
            fetch(`${API}/api/friends/mutual/${currentUserId}/${f.id}`).then(res => res.json())
        );
        const mutualResults = await Promise.all(mutualPromises);

        friendsList.innerHTML = friends.map((f, i) => {
            const mutualCount = mutualResults[i].length;
            const initials = getInitials(f.name);
            const interests = f.interests ? f.interests.split(',').slice(0, 3) : [];

            return `
                <div class="col-lg-4 col-md-6 animate-in">
                    <div class="user-card" onclick="viewUserProfile(${f.id})">
                        <div class="user-card-header">
                            <div class="user-avatar" style="background: ${f.avatarColor || '#00d4ff'}">
                                ${initials}
                            </div>
                            <div>
                                <h6>${f.name}</h6>
                                <small><i class="bi bi-geo-alt"></i>${f.location || 'Unknown'}</small>
                            </div>
                        </div>
                        <div class="tags-container">
                            ${interests.map(i => `<span class="tag tag-interest">${i.trim()}</span>`).join('')}
                        </div>
                        ${mutualCount > 0 ? `<div class="mutual-badge"><i class="bi bi-people-fill"></i> ${mutualCount} mutual friend${mutualCount > 1 ? 's' : ''}</div>` : ''}
                    </div>
                </div>
            `;
        }).join('');
    } catch (err) {
        console.error('Failed to load friends:', err);
    }
}

// ──────────────── Friend Requests ────────────────
async function sendFriendRequest(receiverId) {
    if (!currentUserId) {
        showToast('Please select a user first', 'warning');
        return;
    }
    if (currentUserId === receiverId) {
        showToast('Cannot send request to yourself', 'warning');
        return;
    }

    try {
        const res = await fetch(`${API}/api/friends/request`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ senderId: currentUserId, receiverId: receiverId })
        });

        if (res.ok) {
            showToast('Friend request sent! ✨', 'success');
        } else {
            const err = await res.json();
            showToast(err.error || 'Request failed', 'warning');
        }
    } catch (err) {
        showToast('Network error', 'danger');
    }
}

async function acceptFriendRequest(requestId) {
    try {
        await fetch(`${API}/api/friends/accept/${requestId}`, { method: 'POST' });
        showToast('Friend request accepted! 🎉', 'success');
        loadFriends();
    } catch (err) {
        showToast('Failed to accept request', 'danger');
    }
}

async function rejectFriendRequest(requestId) {
    try {
        await fetch(`${API}/api/friends/reject/${requestId}`, { method: 'POST' });
        showToast('Friend request rejected', 'info');
        loadFriends();
    } catch (err) {
        showToast('Failed to reject request', 'danger');
    }
}

// ──────────────── Shortest Path ────────────────
async function findShortestPath() {
    const fromId = document.getElementById('pathFrom').value;
    const toId = document.getElementById('pathTo').value;
    const resultDiv = document.getElementById('pathResult');

    if (!fromId || !toId) {
        showToast('Please select both users', 'warning');
        return;
    }

    try {
        const res = await fetch(`${API}/api/graph/path/${fromId}/${toId}`);
        const data = await res.json();

        resultDiv.style.display = 'block';

        if (data.path.length === 0) {
            resultDiv.innerHTML = `
                <p class="mb-0"><i class="bi bi-exclamation-triangle text-amber"></i> <strong>No connection path found</strong> between these users.</p>
            `;
        } else {
            resultDiv.innerHTML = `
                <p class="mb-2">
                    <i class="bi bi-check-circle text-green"></i>
                    <strong>Shortest path found!</strong> Distance: <span class="text-cyan">${data.distance} hop${data.distance > 1 ? 's' : ''}</span>
                </p>
                <div class="path-nodes">
                    ${data.path.map((node, i) => `
                        ${i > 0 ? '<span class="path-arrow"><i class="bi bi-arrow-right"></i></span>' : ''}
                        <span class="path-node">
                            <i class="bi bi-person-fill text-cyan"></i> ${node.name}
                        </span>
                    `).join('')}
                </div>
            `;

            // Highlight path in the network graph
            if (typeof highlightPath === 'function') {
                highlightPath(data.path.map(n => n.id));
            }
        }
    } catch (err) {
        console.error('Path search failed:', err);
        showToast('Failed to find path', 'danger');
    }
}

// ──────────────── Registration ────────────────
function setupRegisterForm() {
    const form = document.getElementById('registerForm');
    if (!form) return;

    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        const user = {
            name: document.getElementById('regName').value,
            bio: document.getElementById('regBio').value,
            location: document.getElementById('regLocation').value,
            interests: document.getElementById('regInterests').value,
            skills: document.getElementById('regSkills').value,
            avatarColor: document.getElementById('regColor').value
        };

        try {
            const res = await fetch(`${API}/api/users`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(user)
            });

            if (res.ok) {
                const newUser = await res.json();
                showToast(`Welcome, ${newUser.name}! 🎉`, 'success');
                form.reset();
                await loadUsers();
                currentUserId = newUser.id;
                document.getElementById('currentUserSelect').value = newUser.id;
                navigateTo('profile');
            } else {
                showToast('Registration failed', 'danger');
            }
        } catch (err) {
            showToast('Network error', 'danger');
        }
    });
}

// ──────────────── Toast Notifications ────────────────
function showToast(message, type = 'info') {
    const container = document.getElementById('toastContainer');
    const id = 'toast-' + Date.now();

    const icons = {
        success: 'bi-check-circle-fill',
        warning: 'bi-exclamation-triangle-fill',
        danger: 'bi-x-circle-fill',
        info: 'bi-info-circle-fill'
    };

    const colors = {
        success: 'var(--green)',
        warning: 'var(--amber)',
        danger: 'var(--red)',
        info: 'var(--cyan)'
    };

    const toast = document.createElement('div');
    toast.className = 'toast show';
    toast.id = id;
    toast.innerHTML = `
        <div class="toast-body d-flex align-items-center gap-2">
            <i class="bi ${icons[type] || icons.info}" style="color: ${colors[type] || colors.info}; font-size: 1.1rem;"></i>
            <span>${message}</span>
        </div>
    `;

    container.appendChild(toast);
    setTimeout(() => {
        toast.classList.add('fade');
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// ──────────────── Utilities ────────────────
function getInitials(name) {
    if (!name) return '?';
    return name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2);
}
